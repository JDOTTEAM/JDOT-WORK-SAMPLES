# INTEREXY WORK SAMPLES #

## Here you can browse our code samples in various technologies ##

## What we use: ##

* Swift for iOS development 
* Kotlin for Android development
* React Native for Cross-platform development
* PHP, Node.js for Back-end development